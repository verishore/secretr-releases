# Secretr

Secretr is a secure secret management tool implemented in Go. It provides encrypted storage, secure access, backup/restore features, CLI/API interfaces to manage secrets, and encrypted file storage with image rendering capabilities.

## Features

- **Encryption & Security:**
  Uses AES-GCM with a master key derived via Argon2id.
  Device fingerprinting prevents secretr access even if copied to another device.
- **MasterKey Management:**
  - Set up secretr with a MasterKey.
  - Change or rotate the MasterKey.
- **Secret CRUD Operations:**
  - Store (`set`) secrets with support for nested keys (using dot notation).
  - Retrieve (`get`) secrets.
  - Delete secrets.
  - List all secret keys.
- **Environment Integration:**
  - Load and enrich environment variables from secretr.
  - Set a single secret as an environment variable.
- **Backup & Restore:**
  - Create backup copies via API or CLI.
  - Restore from backup files.
- **CLI & API:**
  - Interactive CLI for managing secrets (`set`, `get`, `delete`, `copy`, `copy-file`, `env`, `enrich`, `list`).
  - HTTP endpoints for key management, backup, and restore (see `/secretr/backup` and `/secretr/restore` endpoints).
- **Audit Logging:**
  Writes audit logs with HMAC signatures to ensure tamper detection.
- **Plan-Aware Storage Quotas:**
  Enforces vault size caps from the active license (Personal/Starter 500 MB, Professional/Pro 2 GB, Team 5 GB) with unlimited storage for higher tiers or unset plans. Saves that would exceed the cap are rejected up front so CLI, GUI, and API users see the same guardrail.
- **Operational Observability:**
  Exposes `/healthz`, `/readyz`, and `/metrics` endpoints for uptime probes and Prometheus scraping.
- **Additional Utilities:**
  - Copy secrets to the clipboard or materialize them into `.env`/JSON files for app configs.
  - Import/export secretr data (JSON format).

## Installation

### Quick install (CLI + GUI)

Download and run the installer directly:

```bash
curl -fsSL https://raw.githubusercontent.com/verishore/secretr/main/install.sh | sh
# or
wget -qO- https://raw.githubusercontent.com/verishore/secretr/main/install.sh | sh
```

The script detects your OS (Linux, macOS, or Windows via Git Bash), checks `https://github.com/verishore/secretr/tree/main/releases/latest` for the newest metadata, falls back to the GitHub Releases API only when that manifest is missing, installs the CLI into `~/.local/bin` (or `/usr/local/bin` when run with sudo), and installs the GUI as a desktop app (`.desktop` entry on Linux or `.app` bundle on macOS). Windows users get both binaries plus a Start Menu shortcut when PowerShell is available.

Customize the installer by exporting the environment variables you need before running it:

| Variable | Description |
|----------|-------------|
| `SECRETR_PREFIX` | Alternate installation prefix (default `~/.local`, set to `/usr/local` when running with sudo). |
| `SECRETR_GUI_DIR` | Override GUI destination (`/opt/secretr` on Linux, `/Applications/Secretr.app` or `~/Applications/Secretr.app` on macOS, `%LOCALAPPDATA%/Programs/Secretr` on Windows). |
| `SECRETR_VERSION` / `SECRETR_TAG` | Pin a specific release (e.g., `SECRETR_VERSION=1.4.2`). |
| `SECRETR_SKIP_GUI` | Set to `1` to install the CLI only. |
| `SECRETR_GITHUB_TOKEN` / `GITHUB_TOKEN` | Token for authenticated GitHub API requests (avoids rate limiting in CI). |
| `SECRETR_LATEST_BASE` / `SECRETR_LATEST_VERSION_URL` / `SECRETR_LATEST_MANIFEST_URL` | Point the "latest" metadata lookup at a custom mirror (defaults to `releases/latest` in the repo). |
| `SECRETR_RELEASE_API` | Override the GitHub API endpoint when mirroring releases. |
| `SECRETR_DOWNLOAD_BASE` | Force artifacts to download from a specific origin (skips manifest-provided base URL). |

Example (system-wide install on Linux/macOS):

```bash
curl -fsSL https://raw.githubusercontent.com/verishore/secretr/main/install.sh | sudo SECRETR_PREFIX=/usr/local sh
```

### Manual build

1. Clone the repository:
  ```bash
  git clone https://github.com/oarkflow/secretr.git
  ```
2. Build the project:
  ```bash
  cd secretr
  go build ./cmd/main.go
  ```

## Usage

### Command-line Interface

Secretr provides both an interactive CLI mode and direct command execution for use in scripts and automation.

#### Interactive Mode

- **Initialize and execute secretr:**
  ```bash
  ./secretr
  ```
- **Interactive commands:**
  - `set <key>`: Set a secret. The tool will prompt for the value securely.
  - `get <key>`: Retrieve the value of a secret.
  - `delete <key>`: Remove a secret.
  - `copy <key>`: Copy the secret to the clipboard.
  - `copy-file --file <path> <key...>`: Copy one or more secrets into `.env` or JSON files. Quote `*` (e.g. `'*'`) or use `--all` to copy every secret.
  - `env <key>`: Set the secret as an environment variable.
  - `load-env`: Load all environment variables from the secretr.
  - `enrich`: Enrich the process's environment with all secretr secrets.
  - `list`: Display all keys stored in secretr.
  - `exit` / `quit`: Save and exit the CLI.

#### Direct Command Execution (for Bash/Make)

Secretr can be invoked directly from bash scripts, Makefiles, and other automation tools:

```bash
# Get a secret (both forms work)
secretr get api_key
secretr api_key

# Set a secret
secretr set api_key "sk-1234567890"

# Delete a secret
secretr delete api_key

# List all secrets
secretr list

# Copy selected secrets into an .env file
secretr copy-file --file=.env aws.host aws.secret

# Copy every secret into a JSON config (auto-detects format)
secretr copy-file --file=config/settings.json --all
```

The `copy-file` command auto-detects `.env` vs JSON based on the file extension/content and creates missing files if needed. Override detection with `--format env` or `--format json` when necessary. Existing entries are updated in-place so repeated runs keep configuration files synced with your vault. When a secret contains JSON, its nested keys are flattened into ENV-style variables (e.g. `aws` → `AWS_API_KEY`, `AWS_SECRET_KEY`). Use `key.*` to target only the nested children of a specific secret.

**Nested Key Access (Dot Notation):**

Store complex configurations as JSON and access nested values:

```bash
# Store a JSON object
secretr set aws_config '{"region":"us-east-1","access_key":"AKIAIOSFODNN7EXAMPLE","secret_key":"wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"}'

# Access nested values with dot notation
AWS_REGION=$(secretr aws_config.region)
AWS_ACCESS_KEY=$(secretr aws_config.access_key)
AWS_SECRET_KEY=$(secretr aws_config.secret_key)
```

#### Master Key Resolution

Secretr automatically resolves the master key in the following order:

1. **SECRETR_MASTERKEY Environment Variable** (Recommended for automation)
   ```bash
  export SECRETR_MASTERKEY="your-master-key"
   secretr api_key
   ```

2. **Shamir Secret Sharing** (For distributed key management)
   ```bash
   # Initialize vault with key distribution
   secretr --distribute-key

   # Keys are split into shares stored in ~/.secretr/masterkey_shares
   # Secretr automatically reconstructs the key when needed
   secretr api_key
   ```

3. **Interactive Prompt** (Fallback for terminals)
   ```bash
   # If no env var or shares exist, prompts for key
   secretr api_key
   # Enter MasterKey: ****
   ```

#### Usage in Bash Scripts

Example bash script (`deploy.sh`):

```bash
#!/usr/bin/env bash

# Set master key for automated execution
export SECRETR_MASTERKEY="your-master-key"

# Retrieve secrets
VPS_HOST=$(secretr server.host)
VPS_USER=$(secretr server.user)
VPS_PASSWORD=$(secretr server.password)

# Use secrets
echo "Deploying to $VPS_HOST..."
sshpass -p "$VPS_PASSWORD" ssh $VPS_USER@$VPS_HOST 'bash deploy.sh'

# Error handling
if API_KEY=$(secretr api_key 2>/dev/null); then
    echo "API Key found"
else
    echo "Error: API Key not found" >&2
    exit 1
fi
```

See `examples/bash.sh` for more comprehensive examples.

#### Usage in Makefiles

Example Makefile:

```makefile
# Set master key before running make
# export SECRETR_MASTERKEY="your-master-key"

.PHONY: deploy
deploy:
	@HOST=$$(secretr production.host); \
	USER=$$(secretr production.user); \
	ssh $$USER@$$HOST 'bash -s' < deploy.sh

.PHONY: db-migrate
db-migrate:
	@DB_URL=$$(secretr database.connection_url); \
	psql "$$DB_URL" -f migrations/latest.sql

.PHONY: docker-push
docker-push:
	@REGISTRY=$$(secretr docker.registry); \
	USERNAME=$$(secretr docker.username); \
	PASSWORD=$$(secretr docker.password); \
	echo "$$PASSWORD" | docker login $$REGISTRY -u $$USERNAME --password-stdin; \
	docker push $$REGISTRY/myapp:latest
```

See `examples/Makefile` for more deployment and CI/CD examples.

#### CLI Flags

```bash
secretr [flags] [command] [arguments]

Flags:
  -distribute-key     Distribute MasterKey using Shamir secret sharing
  -check-device       Check device fingerprint (default: true)
  -mode string        Runtime mode (standard|pro; default: standard)
  -server             Run in HTTP server mode (Pro mode only)
  -http-addr string   HTTP server address
  -silent             Silent mode - suppress non-essential output

Commands:
  get <key>           Get secret value by key (supports dot notation)
  <key>               Shorthand for get - retrieve secret value
  set <key> <value>   Set a secret
  delete <key>        Delete a secret
  list                List all secret keys
  (no command)        Enter interactive CLI mode

#### Top-Level Command Catalog

The CLI currently exposes every feature listed below (subject to license/plan entitlements). Keeping the list in the README makes it easy to spot gaps between docs and reality, while the automated test `TestCLICommandHelpCoverage` fails in CI anytime a new command is added without a corresponding test case.

- **Core & session:** `cli`, `version`, `build-info`, `status`, `close`, `help`, `store`, `get`, `set`, `delete`, `list`, `copy`, `env`, `load-env`
- **Utilities & security:** `ssh-key`, `password`, `enrich`, `import`, `export`, `from-file`, `copy-file`, `gen-jwt`, `gen-apikey`, `gen-keypair`, `gen-symmetric`, `ssh`, `ssh-profile`, `hash`, `observability`, `vault-security`, `security-policy`, `view`
- **Advanced vault operations:** `listkv`, `rollbackkv`, `vcs`, `dynamic`, `certificate`, `sign`, `verify`, `scratchpad`, `enable-2fa`, `disable-2fa`, `enable-passkey`, `disable-passkey`
- **Collaboration & automation:** `share`, `p2p-share`, `template`, `rotate`, `files`
- **Team / ops tooling:** `backup`, `tenant`, `server`, `server-config`, `enable-share-prompt`
- **Sandboxing & retention:** `sandbox`, `secure-sandbox`, `retention`
- **Enterprise controls:** `container`, `fips`, `compliance`, `classify`, `breach`, `access-review`
- **SSO & maintenance:** `sso-login`, `sso-status`, `reset-hard`, `distribute-key`, `vault`, `import-from-server`, `export-to-server`, `export-from-server`

For per-command flag reference and usage snippets, see `docs/COMMANDS.md`.
```

#### Environment Variables

- `SECRETR_MASTERKEY` - Master key for vault access (recommended for automation)
- `SECRETR_DIR` - Custom secretr directory (default: ~/.secretr)
- `SECRETR_MASTERKEY_DIR` - Custom directory for Shamir shares

## Runtime Modes

Secretr now ships with two straightforward runtime modes instead of external license files. Select the mode that matches your deployment requirements:

| Mode | Description |
|------|-------------|
| `standard` (default) | Local-first CLI experience with Shamir sharing, templates, files, SSH, certificates, tenants, sharing, and rotation jobs. HTTP services are disabled to minimize attack surface. |
| `pro` | Opt-in mode that unlocks the embedded HTTP/JSON API, observability endpoints, and GUI/web assets so you can run Secretr as a long-lived service. |

### Switching Modes

- **CLI:** pass `-mode=pro` (or `-mode=standard`) on the `secretr` command line. The default remains standard mode.
- **Embedded usage:** call `secretr.SetRuntimeMode(secretr.ModePro)` (or `ModeStandard`) before invoking `StartSecureHTTPServer`.

### HTTP Server Availability (Pro Only)

The `-server` flag and `secretr.StartSecureHTTPServer` automatically enforce the mode:

- In **Standard** mode the flag is rejected and the helper is a no-op so HTTP services never start by accident.
- In **Pro** mode you can run the daemon as before:

```bash
secretr -mode=pro -server -http-addr :8080 -user-db users.csv
```

Attempts to enable the server without `-mode=pro` exit early with a clear error message.

### API Endpoints (Pro Mode)

Available once the Pro mode HTTP server is running:

- **List & Retrieve Keys:**
  - GET `/secretr/` or `/secretr/keys` to list all keys.
  - GET `/secretr/<key>` to retrieve a specific secret.
- **Add/Update a Secret:**
  - POST/PUT `/secretr/<key>` with the secret in the request body.
- **Delete a Secret:**
  - DELETE `/secretr/<key>`
- **Clear Secretr:**
  - PATCH `/secretr/clear` to remove all secrets.
- **Backup & Restore:**
  - POST `/secretr/backup` to create a backup file.
  - POST `/secretr/restore?path=<backup_path>` to restore the secretr from a backup file.

### Observability Endpoints (Pro Mode)

- `GET /healthz` returns liveness information (uptime, version, commit).
- `GET /readyz` returns a JSON readiness report (vault + storage) and fails with `503` when unhealthy.
- `GET /metrics` exposes Prometheus metrics for HTTP traffic and vault operations.

### File API Endpoints

Secretr provides encrypted file storage with dedicated HTTP endpoints:

- **Upload File:**
  - POST `/api/files` - Upload a file with metadata (multipart/form-data)
  - Form fields: `file` (required), `tags` (comma-separated), `prop_*` (custom properties)
- **List Files:**
  - GET `/api/files` - Get a list of all stored files and their metadata
- **Download File:**
  - GET `/api/files/{filename}` - Download a specific file
- **Render Image:**
  - GET `/api/files/render/{filename}` - Render an image file directly in the browser (only works for image files)
- **Delete File:**
  - DELETE `/api/files/{filename}` - Delete a specific file

## Configuration

- **Secretr Directory:**
  By default, the secretr uses the `.secretr` directory in your home folder. You can override this by setting the `SECRETR_DIR` environment variable.

## Examples

- **CLI Example:**
  ```bash
  secretr> set my.secret
  Enter secret: *************
  secretr> get my.secret
  *************
  secretr> list
  my.secret
  ```
- **Programmatic Usage:**
  See `/examples/main.go` for an example that loads environment variables and retrieves secrets.

## Security Considerations

- Secretr encrypts your secrets on disk. Ensure your master key is kept secure.
- Secretr files are bound to the device they were created on using device fingerprinting.
- Even if a secretr file is copied and the master key is known, it cannot be accessed from a different device.
- Regularly back up your secretr using the provided backup commands.
- Audit logs are stored in the secretr directory to track operations.
